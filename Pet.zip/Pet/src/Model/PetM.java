
package Model;


public class PetM {
     private String nome;
    private int idade;
    private String porte;
    int idCliente;
    
    public int getIdClienteo(){
        return idCliente;
    }
    
    public void setIdCliente(int id){
        this.idCliente=id;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getPorte() {
        return porte;
    }

    public void setPorte(String porte) {
        this.porte = porte;
    }
    

    


}
