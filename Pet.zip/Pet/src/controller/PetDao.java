
package controller;

import Model.PetM;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;



public class PetDao extends ConectarDao {
    private PreparedStatement ps;
    private ResultSet rs;
    
    public PetDao() {
        super();
    }
    public ResultSet buscarTodos(){
String sql= "SELECT * FROM PET ORDER BY IDdoCliente";
            try {
                ps = mycon.prepareStatement(sql);
return ps.executeQuery();
            } catch (Exception e) {
                System.out.println();
            }
return null;
}

         public void criarBanco(PetM pet) {
        try {
        String sql = "INSERT INTO PET(NOME, IDADE, PORTE) VALUES (?, ?, ? )";
        ps = mycon.prepareStatement(sql);
        ps.setString(1, pet.getNome());
        ps.setInt(2, pet.getIdade());
        ps.setString(3, pet.getPorte());

        ps.execute();
        ps.close();
        JOptionPane.showMessageDialog(null, "Registro de Pet Incluído com Sucesso!");
    } catch (SQLException err) {
        JOptionPane.showMessageDialog(null, "Erro ao incluir registro de Pet!" + err.getMessage());
    }
        

    }
    public ArrayList<PetM> obterTodosPets() {
        ArrayList<PetM> pets = new ArrayList<>();
        try {
            String sql = "SELECT * FROM PET";
            ps = mycon.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                PetM pet = new PetM();
                pet.setNome(rs.getString("NOME"));
                pet.setIdade(rs.getInt("IDADE"));
                pet.setPorte(rs.getString("PORTE"));
                pets.add(pet);
            }

            rs.close();
            ps.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao obter registros de Pet!" + err.getMessage());
        }
        return pets;
    }
}

