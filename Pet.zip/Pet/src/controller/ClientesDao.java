
package controller;


import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Cliente;

public class ClientesDao extends ConectarDao {
    private PreparedStatement ps;
    private ResultSet rs;

    public ClientesDao() {
        super();


    }
    
    
  
        public void criarBanco(Cliente cliente) {
        try {
            String sql = "INSERT INTO CLIENTE(NOME, CPF, TELEFONE, ENDERECO, EMAIL) VALUES (?, ?, ?, ?, ?)";
            ps = mycon.prepareStatement(sql);
            ps.setString(1, cliente.getNome());
            ps.setString(2, cliente.getCPF());
            ps.setString(3, cliente.getTelefone());
            ps.setString(4, cliente.getEndereco());
            ps.setString(5, cliente.getEmail());

            ps.execute();
            ps.close();
         JOptionPane.showMessageDialog(null, "Registro de Cliente Incluído com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir registro de Cliente!" + err.getMessage());
        }
    }
         public void incluir(Cliente Cliente) {
        criarBanco(Cliente);
    }
         public ArrayList<Cliente> obterTodosClientes() {
        ArrayList<Cliente> pets = new ArrayList<>();
        try {
            String sql = "SELECT * FROM CLIENTE";
            ps = mycon.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Cliente cli = new Cliente();
                cli.setNome(rs.getString("NOME"));
                cli.setCpf(rs.getString("CPF"));
                cli.setEmail(rs.getString("EMAIL"));
                cli.setTelefone(rs.getString("TELEFONE"));
                cli.setEndereco(rs.getString("ENDERECO"));
                pets.add(cli);
            }

            rs.close();
            ps.close();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao obter registros de Cliente!" + err.getMessage());
        }
        return pets;
    }

}