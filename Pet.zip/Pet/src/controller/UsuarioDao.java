package controller;
import java.sql.SQLException;
import java.sql.PreparedStatement; // Dentro da conexão permite executar comandos SQL
import javax.swing.JOptionPane;

public class UsuarioDao extends ConectarDao { String sql;
PreparedStatement ps; 

public UsuarioDao(){ super(); 
}

 public void criarBanco () {
        
         

        try {
           sql=("CREATE DATABASE IF NOT EXISTS petshop");
            ps.execute();
            
            sql=("USE petshop");
             ps = mycon.prepareStatement(sql);
            ps.execute();
            
                       
            sql= "create table  if not exists clientes(  "
                    + "IDdoCliente INT AUTO_INCREMENT PRIMARY KEY,"
                    + "Telefone varchar(20),"
                    + "CPF VARCHAR(20),"
                    + "Nome VARCHAR(100),"
                    + "Endereco VARCHAR(100),"
                    + "Email VARCHAR(100) )";
            ps = mycon.prepareStatement(sql);
            ps.execute();
            
            
           sql= "create table  if not exists Pet( "
                    + "IDdoPet INT AUTO_INCREMENT PRIMARY KEY,"
                    + "Nome VARCHAR(100),"
                    + "CPF VARCHAR(20),"
                    + "Idade INT,"
                    + "Porte VARCHAR(100),"
                    + "Pedigree INT)";
            ps = mycon.prepareStatement(sql);
            ps.execute();
            
            
            sql= "create table  if not exists funcionario(  "
                    + "IDdoFuncionario INT AUTO_INCREMENT PRIMARY KEY,"
                    + "Nome VARCHAR(100),"
                    + "Telefone INT,"
                    + " CPF VARCHAR(20))";      
            ps = mycon.prepareStatement(sql);
            ps.execute();
            
             sql= "create table  if not exists Servicos(  "
                    + "IDdoServico INT AUTO_INCREMENT PRIMARY KEY,"
                    + " Tipos VARCHAR(50),"
                    + "Preco DECIMAL(10, 2))";
            ps = mycon.prepareStatement(sql);
            ps.execute();
            
             sql= "create table  if not exists Agendamento(  "
                    + " IDdoAgendamento INT AUTO_INCREMENT PRIMARY KEY,"
                    + "IDdoCliente INT,"
                    + "IDdoFuncionario INT,"
                    + " Horario TIME,"
                     + "Data DATE,"
                     + "FOREIGN KEY (IDdoCliente) REFERENCES Cliente(IDdoCliente),"
                     + "FOREIGN KEY (IDdoFuncionario) REFERENCES Funcionario(IDdoFuncionario) )";
            ps = mycon.prepareStatement(sql);
            ps.execute();
            
             
       ps.close(); 
mycon.close(); 
JOptionPane.showMessageDialog(null, "Banco criado com sucesso...");
} catch (SQLException err) {
JOptionPane.showMessageDialog(null, "Erro ao criar banco de dados " + err.getMessage() );
        }
    
    }
    

}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */