/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;



public class ConectarDao {
     public  Connection mycon = null;
    public String       sql = null;
    
   private static final String url = "jdbc:mysql://localhost:3306/PetMiau";
    private static final String user = "root";
    private static final String senha = " ";

    public ConectarDao () {
        String strcon = "jdbc:mysql://localhost:3306/petMiau";//cria a string de conexão ao servidor xaamp 
        try {

            mycon = DriverManager.getConnection(strcon, "root", "");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Conexão com Mysql não realizada!\n" + ex);
        }
    }

}
