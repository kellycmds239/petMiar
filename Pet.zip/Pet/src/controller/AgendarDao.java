/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import Model.AgendarM;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import views.Agendar;

/**
 *
 * @author Kelly
 */
public class AgendarDao extends ConectarDao { 
 private PreparedStatement ps;

    
public AgendarDao(){ 
    super(); 

}

    public void criarBanco(AgendarM agendar) {
try {
    
            String sql = "INSERT INTO AGENDAMENTO(DATA, HORARIO) VALUES (?, ?)";
            ps = mycon.prepareStatement(sql);
             ps.setDate(1, new Date(agendar.getData().getTime())); 
            ps.setString(2, agendar.getHorario());
            

            ps.execute();
            ps.close();
         JOptionPane.showMessageDialog(null, "Registro de Agendamento Incluído com Sucesso!");
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir registro de agendamento!" + err.getMessage());
        }
    }
         public void incluir(AgendarM agendar) {
        criarBanco(agendar);
    }

}
